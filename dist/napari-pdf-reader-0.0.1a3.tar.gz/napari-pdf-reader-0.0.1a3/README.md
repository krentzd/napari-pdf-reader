# PDF reader for napari
Reads PDF files into napari
